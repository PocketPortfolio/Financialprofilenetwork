## Summary

## Screenshots / Demos

## Checklist
- [ ] Tests cover changes
- [ ] a11y checked (axe/Testing Library)
- [ ] i18n strings extracted
- [ ] Perf budgets respected
- [ ] Conventional commit title
