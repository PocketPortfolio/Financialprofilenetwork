# Design Voting Rules
- Post options A/B/C with images or Figma links in a 'Design Vote' Discussion.
- Voting window: 5 days. Count 👍 reactions on top-level option comments.
- Votes from accounts <7 days old noted but not counted.
- Tie-breakers: PM decides with a short rationale.
- After close: post results; convert winning option into issues.
