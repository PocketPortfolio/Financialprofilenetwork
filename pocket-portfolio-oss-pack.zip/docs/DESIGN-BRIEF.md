# DESIGN BRIEF: <Title>
Spec: <link>
Goals:
- <bullets>
Deliverables:
- Screens (desktop/mobile), components, tokens if needed
Constraints:
- Brand, existing grid, timebox
Review date: <YYYY-MM-DD>
