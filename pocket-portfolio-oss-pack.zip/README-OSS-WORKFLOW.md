## 🗳️ Open Contribution Workflow (Pocket Portfolio)
- Give feedback via GitHub Issues (use '💡 Feedback / Idea' form).
- We prioritise with RICE, publish a SPEC in Discussions, designers propose options.
- Community votes on designs, then engineers implement.
- Eng Lead approval required via CODEOWNERS before merge.
